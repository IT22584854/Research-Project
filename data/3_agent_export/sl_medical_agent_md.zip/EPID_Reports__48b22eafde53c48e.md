Doc ID: 48b22eafde53c48e3c28d3fc3cf798464a3154f64389ae6f03bbe4f8dcb94bf4
Site: EPID_Reports
Source PDF: EPID_Reports_vol_35_no_38_english.pdf
Title: WEEKLY EPIDEMIOLOGICAL REPORT

<!-- image -->

## WEEKLY EPIDEMIOLOGICAL REPORT

A publication of the Epidemiological Unit,

## Ministry of Healthcare &amp;  Nutrition

231, de Saram Place, Colombo 01000, Sri Lanka.

Tele:(+94-011)2695112, 681548, 4740490, 4740492, 2677600 Fax: 2696583

Epidemiologist:(+94-011) 4740491, E-mail:[REDACTED_EMAIL], [REDACTED_EMAIL] Web: www.epid.gov.lk

Vol. 35 No. 38                                    13

th - 19 th  September 2008

## AEFI SURVEILLANCE REPORT- 2007 [Part I]

Immunization is one of the public health interventions  that  have  had  the  greatest  impact  on the world's health since its discovery. Thanks to pioneers  like  Sir  Edward  Jenner,  the  first  vaccine  against  small  pox  was  introduced  in  1798 and these vaccines, since then, have helped save many lives and dramatically reduced the burden of many diseases in all four corners of the world. Immunization  is  one  of  the  most  cost  effective interventions and has given great credibility to the global preventive health movement.

Sri Lanka too adopted immunization as a part of its  primary  health  care  services  many  decades ago and a big step forward was taken with the launching  of the Expanded Programme on Immunization  in  1978.  Since  then  the  EPI  programme in the country has been a great success story  often  commended  by  the  World  Health Organization  as  being  a  programme  of  excellence that has achieved many high standards in immunization.

Although  the  first  vaccines  invented  were,  in some  aspects,  crude,  the  vaccines  became  more safe  as  well  as  more  effective  with  time.  But, these vaccines are not entirely without risk. Effective  vaccines  may  produce  some  undesirable side effects which are mostly mild and clear up quickly. These adverse effects can jeopardize the entire  immunization  programme  and  the  credi- bility  achieved  among  the  public  over  many years can be lost. Recognizing the importance of this  critical  issue,  the  Epidemiological  Unit  introduced  the  surveillance  of  Adverse  Events Following Immunization in 1996 as an integral part of the programme.   Furthermore, technological advances and continuously increased knowledge about vaccines have led to investigations  focused  on  the  safety  of  existing  vaccines which have sometimes created a climate for concern.

An Adverse Events Following Immunization is a medical incident that takes place after immunization and is believed to be caused by immunization. The majority of events, though thought to be  related  to  the  administration  of  the  vaccine, are actually not due to the vaccine itself. Many are  simply  coincidental  events  and  others  are due  to  human  or  programme  errors  that  could have been prevented by observing the standard precautions  in  healthcare.  Some  reactions  are solely due to the anxiety and have no association with the vaccine. The determination of AEFI is based on case investigations.

AEFI can create panic among the public leading to ultimate refusal of immunization of  children. This  would  have  drastic  consequences  and  the diseases  that  were  controlled  greatly  could  reemerge,  taking  back  years  of  commitment  and hard work.

| ## Contents  ## Page  1.Leading Article -  AEFI Surveillance Report -2007 [Part I]  2. Surveillance of vaccine preventable diseases &amp; AFP (6 th - 12 th September 2008)  3. Summary of newly introduced notifiable diseases (6  th  - 12  th  September 2008)  4. Laboratory surveillance of dengue fever (6 th - 12 th September 2008)  5. Summary of selected notifiable diseases reported (6 th - 12 th September 2008)  1  3  3  3  4   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Especially  at  a  time  when  vaccine  preventable  diseases  are hardly  seen,  convincing  mothers  to  vaccinate  their  children against such diseases with a vaccine that could have adverse events, is a challenge. Therefore taking all necessary  steps  to  prevent  the  occurrence  of  these AEFI and taking corrective measures can have a major impact on the continuation of the immunization programme.

Systematic  collection,  analysis  and  dissemination of data or surveillance of AEFI can greatly help in facing  the  challenge  of  maintaining  public  confidence in immunization. It is not possible to predict every individual who might have mild or serious reactions to a vaccine. Hence it is mandatory to keep track of every child vaccinated and report any adverse event thought to have occurred due to the vaccine.

Field  health  staff  plays  a  key  role  in  this  regard and  every  month  the  Medical  Officers  of  Health are expected to investigate every individual event and  provide  a  return  on  the  AEFI  observed  in their respective areas to the Epidemiological Unit at  the  central  level.  The  Epidemiological  Unit analyzes these data and makes policy decisions at the centre as and when necessary.

Since the introduction of the surveillance  on AEFI in 1996,  the  reporting  has  shown  impressive  improvements.  A  marked  improvement  is observed in the completeness of reports received at the central level and in 2006 91% of the reports expected were received whereas in 2007 the figure has risen to 97%.  The number of AEFI reported too has shown an increase by about 2000 events together with the rate of AEFI indicating stronger surveillance at the grass root level.

Completeness of AEFI reports received and number and overall rate of AEFI reported in 2006 &amp; 2007

| 2006  2007  Number of monthly reports received  3156  3417  Percentage of reports received  91%  97%  Number of AEFI reported  4184  6217  Overall rate of AEFI reported*  61.5  94.5   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Even though the completeness was at a satisfactory level the timeliness was below expectations and overall only 37.1% of the returns were received on time. Time is a vital ingredient in  epidemiology. Timeliness, or the lack of it, is one of biggest obstacles in achieving high standards in AEFI reporting.

| Completeness of monthly reporting and receipt of NIL  returns by RDHS division - 2006 &amp; 2007  Completeness %  NIL returns  2006  2007  2006  2007  %  %  %  %  Colombo  96.4  98.8  17.9  12.7  Gampaha  95.6  99.4  27.3  11.2  Kalutara  85.6  96.2  27.4  34.7  Kandy  94.7  97.4  58.2  24.5  Matale  90.8  99.3  58.8  51.1  Nuwara  Eliya  86.9  98.8  46.6  43.4  Galle  94.2  96.1  81.8  69.9  Hamban-  tota  90.8  93.2  46.8  27.6  Matara  90.6  98.9  55.2  50.5  Jaffna  97.6  95.2  91.5  96.3  Kilinochchi  77.1  86.1  91.9  80.7  Mannar  100.0  83.3  93.8  87.5  Vavuniya  93.8  95.8  77.1  82.6  Mulletivu  33.3  88.3  95.0  94.3  Batticaloa  77.3  98.5  92.2  76.2  Ampara  88.1  96.4  67.6  66.7  Trinco-  malee  96.3  98.2  91.4  68.9  Kurunegala  95.1  99.1  53.1  36.9  Puttlam  94.4  96.3  38.2  8.7  Anurad-  hapura  95.6  98.3  65.1  54.9  Polonna-  ruwa  96.4  100.0  48.2  30.9  Badulla  95.0  99.4  70.8  40.8  Monera-  gala  95.8  99.2  60.0  37.8  Ratnapura  90.9  91.2  50.0  49.1  Kegalle  81.6  100  43.4  28.8  Kalmunai  93.1  99.4  88.1  80.0  Sri Lanka  91.3  97.2  58.5  46.2   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Hence  more  emphasis must  be  laid  on  adhering  to  time  to  further improve  the  quality  of AEFI  surveillance by MOOH  and  more  supervision  is  needed  in this  regard  by  the  regional health authorities.

When the overall completeness of the reporting of AEFI is improving many districts other  than  Jaffna  and Mannar showed a progress  at  the  individual level from 2006 to 2007. The prevailing civil conflict in the Northern  part of the country could be the reason  for  the  lack  of improvement  in  those two  districts.  In  2007 two RDHS divisions namely Kegalle and Polonnaruwa,  achieved 100% completeness, while  21  RDHS  divisions out of the 26 scored  more  than  95%. Mannar recorded the lowest coverage as a percentage with only 83.3%.

## Source

1. Quarterly Epidemiological Report, forth quarter 2007, Epidemiology Unit.

This article was compiled by Dr W L S P Perera , Epidemiology Unit Colombo.

Part II of this article will be continued in the next issue .

Table 1: Vaccine-preventable Diseases  &amp;  AFP

| Disease  No. of Cases  by Province  Number  of cases  during  current  week in  2008  Number  of cases  during  same  week in  2007  Total  number  of cases  to date in  2008  Total  number  of cases  to date in  2007  Difference  between  the num-  ber of  cases to  date be-  tween 2008  &amp; 2007  W  C  S  N  E  NW  NC  U  Sab  Acute  Flac-  cid Paralysis  00  00  00  00  01  TR=1  00  00  00  00  01  02  71  61  +14.8%  Diphtheria  00  00  00  00  00  00  00  00  00  00  00  00  00  00.0%  Measles  00  00  01  HA=1  00  00  00  01  PO=1  00  00  02  00  92  50  +80.0%  Tetanus  00  00  00  00  00  00  00  00  00  00  00  27  26  +3.8%  Whooping  Cough  00  01  KD=1  00  00  00  01  PU=1  00  00  00  02  01  38  32  +12.5%  Tuberculosis  67  09  25  02  45  47  07  21  35  258  296  6636  7000  -8.9`%   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Table 2: Newly Introduced Notifiable Diseases

6 th -  12 th   Sep  2008 (37 th  Week)

| Disease  No. of Cases  by Province  Number  of cases  during  current  week in  2008  Number  of cases  during  same  week in  2007  Total  number  of cases  to date in  2008  Total  number  of cases  to date in  2007  Difference  between  the number  of cases to  date be-  tween 2008  &amp; 2007  W  C  S  N  E  NW  NC  U  Sab  Chicken-  pox  13  15  28  02  06  06  02  10  32  114  59  3906  2378  +59.3%  Meningitis  01  KL=1  00  01  HA=1  00  01  BT=1  04  KR=4  02  PO=2  00  04  RP=1  KG=3  13  22  981  408  +136.8%  Mumps  04  15  11  02  23  08  17  01  15  96  105  2150  1346  +52.4%   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Key to Table 1 &amp; 2

Provinces: W=Western, C=Central, S=Southern, N=North, E= East, NC=North Central, NW=North Western, U=Uva, Sab=Sabaragamuwa. DPDHS Divisions: CB=Colombo, GM=Gampaha, KL=Kalutara, KD=Kandy, ML=Matale, NE=Nuwara Eliya, GL=Galle, HB=Hambantota, MT=Matara, JF=Jaffna, KN=Killinochchi, MN=Mannar, VA=Vavuniya, MU=Mullaitivu, BT=Batticaloa, AM=Ampara, TR=Trincomalee, KM=Kalmunai, KR=Kurunegala, PU=Puttalam,  AP=Anuradhapura, PO=Polonnaruwa, BD=Badulla,  MO=Moneragala, RP=Ratnapura, KG=Kegalle.

Table 3: Laboratory Surveillance of Dengue Fever  6 th    -  12 th   Sep  2008 (37 th  Week)

| Samples  Number  tested  Number  positive *  Serotypes  D1  D2  D3  D4  Negative  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  Number for current week  00  00  00  00  00  00  00  00  00  00  00  00  00  00  Total number to date in 2008  124  132  09  22  00  00  06  08  01  08  00  00  02  00   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Sources: Genetech Molecular Diagnostics &amp; School of Gene Technology, Colombo [GT] and Genetic Laboratory Asiri Surgical Hospital [AH]

* Not all positives are subjected to serotyping.

NA = Not Available.

Data Sources:

Weekly Return of Communicable Diseases: Diphtheria, Measles, Tetanus, Whooping Cough, Human Rabies, Dengue Haemorrhagic Fever, Japanese Encephali tis, Chickenpox, Meningitis, Mumps.

Special Surveillance:

Acute Flaccid Paralysis.

## Table 4:  Selected notifiable diseases reported by Medical Officers of Health

6 th -  12 th   Sep  2008 (37 th  Week)

| DPDHS  Division  Dengue  Fever /  DHF*  Dysentery  Encephal  -itis  Enteric  Fever  Food  Poisoning  Leptos-  pirosis  Viral                  Human-  Hepatitis           Rabies  Re-  turns  Re-  ceive  A  B  A  B  A  B  A  B  A  B  A  B  A  B  A  B  %  Colombo  11  1276  10  182  01  14  07  93  01  86  122  537  00  02  00  92  77  Gampaha  07  784  02  158  00  17  00  41  00  98  27  491  00  06  09  132  64  Kalutara  10  384  02  247  00  11  01  46  00  20  17  402  00  02  00  36  75  Kandy  07  210  05  235  00  07  01  49  27  81  07  341  00  81  03  102  72  Matale  06  95  05  169  01  04  02  40  00  04  05  627  00  01  00  24  92  Nuwara  00  22  03  201  01  03  02  202  00  166  01  40  00  36  01  93  77  Galle  01  87  01  139  00  12  00  15  00  43  12  282  00  12  01  08  59  Hambantota  00  79  06  82  00  05  00  07  00  11  02  81  03  75  00  14  45  Matara  05  243  04  152  00  12  02  31  00  06  19  317  09  181  00  14  59  Jaffna  00  52  06  114  00  04  02  229  01  15  00  00  00  151  00  34  88  Kilinochchi  00  00  00  35  00  00  00  01  00  04  00  02  00  00  00  01  00  Mannar  00  25  00  17  00  06  01  153  00  00  00  00  00  01  00  13  50  Vavuniya  00  11  01  52  00  02  00  11  01  16  00  05  00  01  00  05  50  Mullaitivu  00  00  00  11  00  00  00  13  00  13  00  00  00  01  00  09  00  Batticaloa  00  85  02  105  01  05  00  20  01  25  00  05  00  01  02  85  45  Ampara  00  28  02  232  00  00  00  07  00  283  00  20  00  00  00  08  43  Trincomalee  00  177  01  78  01  01  00  13  00  12  00  30  00  16  01  13  60  Kurunegala  08  282  04  182  00  14  01  50  00  16  20  503  00  26  01  58  72  Puttalam  02  274  01  68  00  08  04  145  00  26  04  46  00  35  00  28  56  Anuradhapu  04  115  04  79  00  09  00  11  02  08  03  231  00  10  00  13  53  Polonnaruw  01  62  03  106  00  01  00  21  05  17  00  59  00  01  00  18  57  Badulla  02  75  12  383  00  05  00  114  01  94  03  48  01  103  03  125  53  Monaragala  00  51  03  286  00  03  02  35  00  116  00  87  04  86  00  40  82  Ratnapura  01  231  26  287  00  28  01  43  00  63  04  135  01  77  00  46  44  Kegalle  13  347  04  249  00  25  00  56  01  07  17  295  02  58  07  452  55  Kalmunai  00  34  06  225  00  02  00  09  00  16  00  01  00  02  00  23  54  SRI LANKA  78  5029  113  4074  05  198  26  1455  40  1246  263  4585  20  965  28  1486  61  Typhus  Fever  A  B  00  00  00  04  00  02  01  02  00  00  00  01  00  03  00  01  00  01  00  00  00  00  00  00  00  00  00  00  01  06  00  00  00  00  00  06  00  04  01  03  00  00  00  01  00  00  00  00  00  01  00  00  03  35   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## PRINTING OF THIS PUBLICATION  IS FUNDED BY THE UNITED NATIONS CHILDREN'S FUND (UNICEF).

Comments and contributions for publication in the WER Sri Lanka are welcome. However, the editor reserves the right to accept or reject items for publication. All correspondence should be mailed to The Editor, WER Sri Lanka, Epidemiological  Unit, P.O. Box 1567, Colombo or sent by Email to [REDACTED_EMAIL].

## ON STATE SERVICE

Dr. M. R. N. ABEYSINGHE EPIDEMIOLOGIST EPIDEMIOLOGICAL UNIT 231, DE SARAM PLACE COLOMBO 10
