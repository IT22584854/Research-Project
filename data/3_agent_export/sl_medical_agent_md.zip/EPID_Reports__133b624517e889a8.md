Doc ID: 133b624517e889a897b6109febbe53e005df2fa2da0cfb03db7fe32a92d6a559
Site: EPID_Reports
Source PDF: EPID_Reports_vol_35_no_34_english.pdf
Title: WEEKLY EPIDEMIOLOGICAL REPORT

<!-- image -->

<!-- image -->

## WEEKLY EPIDEMIOLOGICAL REPORT

A publication of the Epidemiological Unit,

## Ministry of Healthcare &amp;  Nutrition

231, de Saram Place, Colombo 01000, Sri Lanka.

Tele:(+94-011)2695112, 681548, 4740490, 4740492, 2677600 Fax: 2696583

Epidemiologist:(+94-011) 4740491, E-mail:[REDACTED_EMAIL], [REDACTED_EMAIL]

Web: www.epid.gov.lk

Vol. 35 No. 34                                      16

th - 22 nd August 2008

## CURRENT OUTBREAK  OF  LEPTOSPIROSIS

This year up to September 5, a total of 4295 leptospirosis  cases  have  been  notified  from all over the country. An alarmingly increasing number  of  cases  have  been  observed  in several districts including Kurunegala, Gampaha  and  Colombo.  The  sentinel  hospitals alone  reported  119  deaths.  Unusually  high case  fatality  rate  is  one  of  the  notable  features  observed  this  year.  All  these  emphasize the need for further strengthening  prevention  and  control  activities  at  all  levels. The activities to be taken by the health workers  and  the  issues/  constrains  encountered during  this  outbreak  are  briefed  in  this  article.

This  acute  generalized  illness  can  mimic other  tropical  diseases  and  the  common symptoms include fever, chills, muscle pain, nausea,  diarrhoea  and  conjunctival  suffusion.  Manifestations  of  severe  disease  can include  jaundice,  renal  failure,  widespread haemorrhage, myocarditis and meningitis. It should be noted that though  the  above symptoms are common, none is specific for leptospirosis. This often leads to mistaken or late diagnosis resulting in high rates of complications  and  fatality.  It  is  recommended (especially  during  outbreaks)  that  fever  patients with a history of exposure to contami- nated  environment  should  be  admitted  for inward management. Even without a proper history  of  exposure,  if  the  patients  present with symptoms/ signs strongly suggestive of leptospirosis, inward management should be considered.

If  the  duration  of  fever  is  more  than  3  -  4 days be vigilant of signs and symptoms suggestive  of  possible  complications  such  as renal  failure,  myocarditis  and  heart  failure, meningitis, and widespread haemorrhage due  to  disseminated  intravascular  coagulation.  Case  fatality  rate  is  reported  to  range from less than 5% to 30% and is mainly due to the above complications. Transferring patients  to  higher  level  institutions  should  be considered if there is a concern about urine output  despite  adequate  hydration.  Symptoms suggestive of cardiac involvement such as hypotension and tachycardia are some of the other indications for transferring patients.

Clinical  suspicion  of  leptospirosis  should  be confirmed  whenever  possible  by  necessary laboratory tests. Confirmatory diagnosis (especially  microscopic  agglutination  testMAT)  could  be  done  at  the  Medical  Research  Institute,  Colombo.  However,  serological tests do not become positive with the

| ## Contents  Page  1.Leading Article -  Current outbreak of  leptospirosis  2. Surveillance of vaccine preventable diseases &amp; AFP (9 th - 15 th August 2008)  3. Summary of newly introduced notifiable diseases (9 th - 15 th August 2008)  4. Laboratory surveillance of dengue fever (9 th - 15 th August 2008)  5. Summary of selected notifiable diseases reported (9 th - 15 th August 2008)  1  3  3  3  4   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

mortem  blood  samples  obtained  within  one  hour  of death  to  confirm  the  diagnosis  in  clinically  suspected cases.

The treating physicians should also notify details of suspected  cases  of  leptospirosis  to  the  Epidemiology  Unit without delay. Early notification and subsequent investigation  by  field  health  staff  are  essential  particularly  to forecast/  track  the  outbreaks  and  take  early  interventions.  In  addition,  sentinel  surveillance  is  carried  out  in selected hospitals in high risk areas. These hospitals are expected to send special investigation forms for all confirmed  cases.  Getting  further  information  on  laboratory investigations conducted and the possible source of exposure is the main objective of this activity.

Since the case fatality is unusually high this year, there is  a  need  to  investigate  the  deaths  also.  All  hospital deaths due to suspected/ confirmed leptospirosis should be  notified  to  the  Epidemiology  Unit  and  the  relevant Regional Epidemiologist over the phone by the hospital staff. In addition, for all reported deaths, duly filled  death investigation forms should be sent from the hospitals (by the  physician  who  treated)  and  from  the  field  (by  the relevant MOH of the area from where the patient hailed) to the Epidemiology Unit. The objective of the death investigation  is  to  identify  the  factors  contributed  to  the deaths and to take remedial action at both field and hospital  levels.  This  is  to  identify  the  shortcomings  in  the system with a view to rectifying these in future  and certainly not to find fault with any individuals.

All information collected by the above means should be rationally used to plan and evaluate prevention and control activities. It is the responsibility of the MOOH to carry out  prevention  and  control  activities  at  the  divisional level. A variety of occupational and recreational activities have been associated with leptospirosis, including farming, gem mining, cleaning drains and canals, veterinary and  abattoir  work,  and  swimming  and  playing  in  contaminated water. The risk of acquiring leptospirosis can be  greatly  reduced  by  avoiding  exposure  to  contaminated water and soil. However, it might not be possible for  people  whose  livelihoods  depend  on  occupations mentioned above. They should be advised on the benefits  of  wearing footwear preferably knee-high boots and protective  clothing.  Wounds/  abrasions  on  skin  should be  covered  with  waterproof  dressing.  Further,  awareness  about  the  disease  should  be  raised  among  risk groups, health care providers and general population, so that  the  disease  can  be  recognized  early  and  treated with the least possible delay.

Chemoprophylaxis  is  not  advocated  as  a  routine  and leading preventive strategy and is recommended only for well  recognized  high  risk  groups.  Identification  of  high risk  localities  at  the  divisional  level  (e.g.  clustering  of cases in a particular area) will help to identify high risk groups. Further, there should be a felt need by the high risk  occupational  groups  of  such  areas  for  prophylaxis e.g. request for prophylaxis made by farmers' organizations.  If  prophylaxis  is  given,  it  should  be  closely  monitored by the MOH and the field health staff. The recommended dose is doxycycline 200 mg weekly during the period  of  possible  exposure.  Doxycycline  is  a  tetracycline  antibiotic  and  should  not  be  given  to  children younger than 12 years old, pregnant and lactating mothers.

Though this ongoing outbreak has been presumed due to  leptospirosis,  more  than  one  pathogenic  agent  may be responsible . For example, hanta virus infections may be part of the current problem in Sri Lanka. Like leptospirosis,  hanta  virus  infection  is  also  a  mainly  rodentborne  zoonotic  infection.  It  often  presents  in  epidemic forms  after  abundant  rainfall,  and  differential  diagnosis with leptospirosis on clinical grounds alone is impossible to be made. Even if the rodent reservoir in Sri Lanka is same for both leptospira and hanta virus - which is far from  proven  -  the  treatment  and  prognosis  of  both  human  infections is totally different. Further, effective measures of prevention and control will not be possible as  long  as  the  exact  mammal  reservoir  is  not  known. These facts underscore the importance of clinical observations being supported by adequate laboratory testing.

## Source

Table 1: Vaccine-preventable Diseases  &amp;  AFP

9 th -  15 th August  2008 (33 rd  Week)

| Disease  No. of Cases  by Province  Number  of cases  during  current  week in  2008  Number  of cases  during  same  week in  2007  Total  number  of cases  to date in  2008  Total  number  of cases  to date in  2007  Difference  between  the num-  ber of  cases to  date be-  tween 2008  &amp; 2007  W  C  S  N  E  NW  NC  U  Sab  Acute  Flac-  cid Paralysis  01  GM=1  00  00  00  01  BT=1  00  00  00  02  RP=1  KG=1  04  01  64  59  +8.53%  Diphtheria  00  00  00  00  00  00  00  00  00  00  00  00  00  00.0%  Measles  00  00  00  00  00  00  00  01  MO=1  02  KG=2  03  01  84  50  +68.3%  Tetanus  00  00  00  00  00  00  00  00  00  00  00  25  23  +8.7%  Whooping  Cough  00  00  00  01  JF=1  00  00  02  KR=1  PU=1  00  00  03  02  29  30  -3.3%  Tuberculosis  33  43  07  04  02  00  05  00  00  205  261  5733  6518  -12.0`%   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Table 2: Newly Introduced Notifiable Diseases

9 th -  15 th August  2008 (33 rd Week)

| Disease  No. of Cases  by Province  Number  of cases  during  current  week in  2008  Number  of cases  during  same  week in  2007  Total  number  of cases  to date in  2008  Total  number  of cases  to date in  2007  Difference  between  the number  of cases to  date be-  tween 2008  &amp; 2007  W  C  S  N  E  NW  NC  U  Sab  Chicken-  pox  25  06  10  00  04  02  02  07  12  67  37  3536  2226  +58.8%  Meningitis  02  GM=2  01  KD=1  03  GL=1  MT=1  HB=1  01  JF=1  00  02  KR=1  PU=1  00  03  BD =3  03  KG=2  RP=1  15  16  903  316  +185.7%  Mumps  06  19  17  20  03  19  13  04  12  113  83  1833  1145  +60.1%   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Key to Table 1 &amp; 2

Provinces: W=Western, C=Central, S=Southern, N=North, E= East, NC=North Central, NW=North Western, U=Uva, Sab=Sabaragamuwa. DPDHS Divisions: CB=Colombo, GM=Gampaha, KL=Kalutara, KD=Kandy, ML=Matale, NE=Nuwara Eliya, GL=Galle, HB=Hambantota, MT=Matara, JF=Jaffna, KN=Killinochchi, MN=Mannar, VA=Vavuniya, MU=Mullaitivu, BT=Batticaloa, AM=Ampara, TR=Trincomalee, KM=Kalmunai, KR=Kurunegala,

Table 3: Laboratory Surveillance of Dengue Fever 9 th -  15 th August  2008 (33 rd  Week)

| Samples  Number  tested  Number  positive *  Serotypes  D1  D2  D3  D4  Negative  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  GT  AH  Number for current week  04  04  00  01  00  00  00  00  00  01  00  00  00  00  Total number to date in 2008  120  128  09  22  00  00  06  08  01  08  00  00  02  00   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Sources: Genetech Molecular Diagnostics &amp; School of Gene Technology, Colombo [GT] and Genetic Laboratory Asiri Surgical Hospital [AH] * Not all positives are subjected to serotyping.

NA

= Not Available.

Data Sources:

Weekly Return of Communicable Diseases: Diphtheria, Measles, Tetanus, Whooping Cough, Human Rabies, Dengue Haemorrhagic Fever, Japanese Encephali tis, Chickenpox, Meningitis, Mumps.

Special Surveillance:

Acute Flaccid Paralysis.

National Control Program for Tuberculosis and Chest Diseases: Tuberculosis.

Table 4:  Selected notifiable diseases reported by Medical Officers of Health 9 th -  15 th August  2008 (33 rd Week)

| DPDHS  Division  Dengue  Fever /  DHF*  Dysentery  Encephal-  itis  Enteric  Fever  Food  Poisoning  Leptos-  pirosis  Viral                  Human-  Hepatitis           Rabies  Re-  turns  Re-  ceive  A  B  A  B  A  B  A  B  A  B  A  B  A  B  A  B  %  Colombo  32  1186  07  137  01  09  04  71  01  75  14  289  00  02  02  86  92  Gampaha  18  715  07  138  00  15  02  36  27  95  22  293  00  05  04  99  64  Kalutara  07  347  01  230  01  10  00  44  00  18  08  335  00  02  00  32  100  Kandy  08  180  06  218  00  05  01  43  00  53  05  317  04  76  01  95  76  Matale  02  82  03  153  00  02  00  35  00  04  04  611  00  01  01  23  100  Nuwara Eliya  00  21  02  181  00  02  01  197  48  158  03  39  00  35  00  87  92  Galle  02  83  03  132  00  12  00  13  00  43  05  241  00  12  00  06  88  Hambantota  02  70  02  68  00  05  00  07  00  11  03  72  01  66  03  12  100  Matara  07  202  03  136  00  10  02  28  00  06  08  239  04  147  00  11  100  Jaffna  00  52  02  99  00  02  03  221  00  11  00  00  02  150  02  32  75  Kilinochchi  00  00  00  23  00  00  00  01  00  00  00  02  00  00  00  01  00  Mannar  00  25  00  15  00  06  06  145  00  00  00  00  00  01  00  13  75  Vavuniya  00  11  02  45  00  02  01  06  00  14  00  05  00  01  01  05  100  Mullaitivu  00  00  00  06  00  00  00  12  00  12  00  00  00  01  00  08  00  Batticaloa  00  85  01  90  01  04  00  20  00  20  01  05  00  01  00  82  73  Ampara  00  26  01  219  00  00  00  07  00  01  00  17  00  00  00  07  14  Trincomalee  01  176  00  70  00  00  01  13  00  12  00  28  01  16  00  12  70  Kurunegala  03  259  04  170  01  14  02  44  00  14  40  249  00  20  00  53  89  Puttalam  01  271  02  61  00  08  03  137  00  26  02  32  00  33  00  27  89  Anuradhapur  00  109  00  60  00  09  01  10  00  06  01  223  00  10  00  12  58  Polonnaruwa  00  59  00  89  00  01  00  21  00  07  00  55  00  01  00  18  86  Badulla  02  66  05  338  00  05  00  101  00  13  00  33  01  98  05  102  93  Monaragala  00  49  02  280  00  03  00  29  00  116  01  87  00  76  05  38  91  Ratnapura  04  213  03  235  00  26  00  42  00  51  01  127  00  74  00  45  88  Kegalle  08  318  02  231  00  24  02  51  00  04  16  240  03  53  05  433  91  Kalmunai  01  33  01  201  00  02  00  09  00  15  00  00  00  02  00  21  62  SRI LANKA  98  4638  59  3625  04  176  29  1343  76  785  134  3539  16  883  29  1360  80  Typhus  Fever  A  B  00  00  01  04  00  01  00  01  00  00  00  01  00  03  00  00  00  01  00  00  00  00  00  00  00  00  00  00  00  05  00  00  00  00  00  04  00  03  00  02  00  00  00  01  00  00  00  00  00  01  00  00  01  27   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Source:  Weekly  Returns of Communicable   Diseases  (WRCD).

*Dengue Fever / DHF refers to Dengue Fever / Dengue Haemorrhagic Fever.

**Timely refers to returns received on or before 23 August, 2008 Total number of reporting units =238. Number of reporting units data provided for the current week:

## PRINTING OF THIS PUBLICATION  IS FUNDED BY THE UNITED NATIONS CHILDREN'S FUND (UNICEF).

Comments and contributions for publication in the WER Sri Lanka are welcome. However, the editor reserves the right to accept or reject items for publication. All correspondence should be mailed to The Editor, WER Sri Lanka, Epidemiological  Unit, P.O. Box 1567, Colombo or sent by Email to [REDACTED_EMAIL].

## ON STATE SERVICE

Dr. M. R. N. ABEYSINGHE EPIDEMIOLOGIST EPIDEMIOLOGICAL UNIT 231, DE SARAM PLACE COLOMBO 10
